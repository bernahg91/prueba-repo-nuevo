# Repositorio template para nuevos proyectos TreeW

Contiene configuración inicial para commits y validaciones.